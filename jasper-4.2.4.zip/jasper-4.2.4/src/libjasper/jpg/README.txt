This directory contains code to support the JPEG image format.  In order
for the code in this directory to be useful, the free JPEG library from
the Independent JPEG Group (IJG) is needed.  For legal reasons, the
IJG JPEG software is not included in the JasPer software distribution.
The IJG JPEG software can be obtained, however, from:
    http://www.ijg.org
